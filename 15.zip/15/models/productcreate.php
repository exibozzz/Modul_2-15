<?php

// Sequrity Check 

        if(!isset($_POST['name']) || empty($_POST['name']))
        {
            die ("You have not entered a product name. ");
        }

        if(!isset($_POST['description']) || empty($_POST['description']))
        {
            die ("You have not entered a product description. ");
        }

        if(!isset($_POST['price']) || empty($_POST['price']))
        {
            die ("You have not entered a product price. ");
        }

        if(!isset($_POST['date']) || empty($_POST['date']))
        {
            die ("You have not entered a purchase date. ");
        }

        if(!isset($_POST['amount']) || empty($_POST['amount']))
        {
            die ("You have not entered a product amount. ");
        }


        $baza = mysqli_connect("localhost","root","","baza");   // Nisam radio povezivanje druge konekcije jer imam identicnih varijable i imena u drugim fajlovima


        // CREATE PRODUCT

        $name = $_POST['name'];
        $description = $_POST['description'];
        $price = $_POST['price'];
        $date = $_POST['date'];
        $amount = $_POST['amount'];


        $insertProduct = $baza->query("INSERT INTO proizvodi (ime, opis, cena, dan_nabavke, kolicina) VALUES ('$name', '$description', '$price', '$date', '$amount')");

       ?>