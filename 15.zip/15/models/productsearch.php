<?php

        // Search product 


        if(!isset($_GET['searchProduct']) || empty($_GET['searchProduct']))
        {
            die ("You have not entered a product search.");
        }

        $baza = mysqli_connect("localhost","root","","baza");   // Nisam radio povezivanje druge konekcije jer imam identicnih varijable i imena u drugim fajlovima


        $searchProduct = $_GET['searchProduct'];

        $searchProductResult = $baza->query("SELECT * FROM proizvodi WHERE ime LIKE '%$searchProduct%' OR opis LIKE '%$searchProduct%'"); 




        if($searchProductResult->num_rows >= 1 )
        {
        
            echo "Products found:".$searchProductResult->num_rows." products." ;
        }

        else 
        {
        echo "No products found.";
        }






?>