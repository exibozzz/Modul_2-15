<?php


    // Insert product sequrity check


            if(!isset($_POST['nameLastName']) || empty($_POST['nameLastName']) )
            {
              die("You have not entered name.");
            }


            if(!isset($_POST['email']) || empty($_POST['email']) )
            {
              die("You have not entered email.");
            }


            if(!isset($_POST['password']) || empty($_POST['password']) )
            {
              die("You have not entered password.");
            }


            if(!isset($_POST['birthday']) || empty($_POST['birthday']) )
            {
              die("You have not entered birthday.");
            }


    $baza = mysqli_connect("localhost", "root", "", "baza");

    $nameLastName = $_POST['nameLastName'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $birthday = $_POST['birthday'];


    $checkEmail = $baza->query("SELECT * FROM korisnici WHERE email = '$email' ");

  

    if($checkEmail->num_rows >= 1) {
        die ("The e-mail address already exists.");
    }

    else {
        echo "You have successfully registered !";
        $baza->query("INSERT INTO korisnici (ime_prezime, email, lozinka, datum_rodjenja) VALUES ('$nameLastName','$email','$password', '$birthday')");

    }







?>