<?php


if(!isset($_GET['email']) || empty($_GET['email'])) 
{
    die ("You have not entered an email to search.");
}

$baza = mysqli_connect("localhost","root","","baza");

$email = $_GET['email'];

$searchEmail = $baza->query("SELECT * FROM korisnici WHERE email = '$email'");

if($searchEmail->num_rows >=1) 
{
    echo "Postoji korisnik koji ima unetu email adresu.";
}
else 
{
    echo "Ne postoji korisnik koji ima unetu email adresu. " ;
}




?>